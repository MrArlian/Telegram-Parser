--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE order_12_10_21;
--
-- Name: order_12_10_21; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE order_12_10_21 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Russian_Russia.1251';


ALTER DATABASE order_12_10_21 OWNER TO postgres;

\connect order_12_10_21

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: channels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.channels (
    pair_id integer NOT NULL,
    user_id integer NOT NULL,
    channel_id_input integer NOT NULL,
    channel_name_input text NOT NULL,
    channel_id_output integer NOT NULL,
    channel_name_output text NOT NULL
);


ALTER TABLE public.channels OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    whitelist text[] DEFAULT '{}'::text[],
    blacklist text[] DEFAULT '{}'::text[],
    online time without time zone DEFAULT '00:00:00'::time without time zone,
    offline time without time zone DEFAULT '23:59:59'::time without time zone,
    control boolean DEFAULT false
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: waiting; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.waiting (
    chat_id bigint NOT NULL,
    user_id integer NOT NULL,
    id integer NOT NULL,
    payload json NOT NULL
);


ALTER TABLE public.waiting OWNER TO postgres;

--
-- Name: users user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT user_id_key UNIQUE (user_id);


--
-- PostgreSQL database dump complete
--

